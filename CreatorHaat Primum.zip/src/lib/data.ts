export const WHATSAPP_NUMBER = "8801611249477";
export const WHATSAPP_LINK = "https://wa.link/b32enw";
export const PHONE_DISPLAY = "+880 1611-249477";
export const EMAIL = "info@creatorhaat.com";
export const BKASH = "01611-249477";
export const NAGAD = "01611-249477";
export const COURSES_EXT_LINK = "https://www.creatorhaat.com/courses/";

import logo from "@/assets/logo.webp.asset.json";
import mentor from "@/assets/admin-mentor.webp.asset.json";
import course1Img from "@/assets/course1.webp.asset.json";
import course2Img from "@/assets/course2.webp.asset.json";
import ss3 from "@/assets/screenshots/ss3.jpeg.asset.json";
import ss4 from "@/assets/screenshots/ss4.jpeg.asset.json";
import ss6 from "@/assets/screenshots/ss6.jpeg.asset.json";
import ss7 from "@/assets/screenshots/ss7.jpeg.asset.json";
import ss8 from "@/assets/screenshots/ss8.jpeg.asset.json";
import ss9 from "@/assets/screenshots/ss9.jpeg.asset.json";
import ss10 from "@/assets/screenshots/ss10.jpeg.asset.json";
import ss12 from "@/assets/screenshots/ss12.jpeg.asset.json";
import ss16 from "@/assets/screenshots/ss16.jpeg.asset.json";
import ss17 from "@/assets/screenshots/ss17.jpeg.asset.json";

export const LOGO_URL = logo.url;
export const MENTOR_URL = mentor.url;

export type Course = {
  slug: string;
  path: string;
  title: string;
  shortTitle: string;
  description: string;
  regularPrice: number;
  offerPrice: number;
  discount: number;
  image: string;
  youtubeId: string;
  whyTake: string[];
  outline: { title: string; items: string[] }[];
  features: string[];
  reviewVideos: string[];
  reviews: { name: string; role: string; text: string; rating: number }[];
};

export const COURSES: Course[] = [
  {
    slug: "usa-shorts",
    path: "/course/usa-shorts",
    title: "30 Days Challenge USA YouTube Shorts Masterclass",
    shortTitle: "USA YouTube Shorts Masterclass",
    description:
      "বর্তমান সময়ে ইউটিউব শর্টস হলো অর্গানিক রিচ ও দ্রুত আয়ের সেরা মাধ্যম। এই কোর্সে শেখানো হবে কিভাবে বাংলাদেশ থেকে সঠিক নিয়মে USA মার্কেট টার্গেট করে প্রফেশনাল মানের শর্টস চ্যানেল তৈরি করবেন। কপিরাইট বা জটিলতা ছাড়াই স্মার্ট অটোমেশন ব্যবহার করে সাস্টেইনেবল প্যাসিভ ইনকাম তৈরির প্রমাণিত স্টেপ-বাই-স্টেপ গাইড।",
    regularPrice: 2999,
    offerPrice: 999,
    discount: 2000,
    image: course1Img.url,
    youtubeId: "QgZMkBpLT_s",
    whyTake: [
      "কম সময়, দ্রুত গ্রোথ – অল্প সময় দিয়ে নিয়মিত শর্টস আপলোডের মাধ্যমে খুব দ্রুত চ্যানেল গ্রো করার সুযোগ।",
      "বাংলাদেশ থেকে বসে USA টার্গেট করে তুলনামূলক বেশি আয়ের জন্য প্রয়োজনীয় সেটআপ ও স্ট্র্যাটেজি শিখবেন।",
      "ভিউ পাওয়ার সম্ভাবনা বেশি – প্রুভড শর্টস স্ট্রাকচার ও প্রেজেন্টেশন ব্যবহার করে ভিডিও রিচ পাওয়ার সুযোগ বাড়ে।",
      "ফেসলেস কন্টেন্ট ক্রিয়েশন – নিজের চেহারা বা ভয়েস না দিয়েই AI টুলস ব্যবহার করে প্রফেশনাল মানের ভিডিও তৈরির পূর্ণাঙ্গ গাইডলাইন।",
      "দীর্ঘমেয়াদি পরিকল্পনা – চ্যানেলকে ভবিষ্যতের স্থায়ী আয়ের উৎস হিসেবে গড়ে তোলার পথ দেখাবো।",
    ],
    outline: [
      { title: "Foundation & Channel Setup", items: ["Success Mindset & Motivation", "YouTube Shorts Automation Introduction", "Professional Gmail Creation", "IP & Device Safety System", "Beginner Setup Guide", "Assignment"] },
      { title: "Niche Research & Viral Content Ideas", items: ["Winning Niche Selection Strategy", "Competitor Research Method", "Unlimited Viral Video Ideas", "USA Audience Targeting", "High CPM Niche Research", "Assignment"] },
      { title: "Professional Channel Setup", items: ["0 Views Problem Solution", "Professional YouTube Channel Creation", "Branding & Optimization", "Success Strategy & Growth Mindset", "Assignment"] },
      { title: "Trending Shorts Content Creation", items: ["Facts Content", "Motivation Content", "Skeleton Content", "Magic Content", "Religious Content", "Map Animation Videos", "Restoration Content", "Ant Content", "Evergreen Cartoon Content", "Assignment"] },
      { title: "Script Writing & AI Voiceover", items: ["Viral Script Writing Formula", "Hook & Audience Retention Strategy", "AI Voiceover Setup", "English Video Creation System", "Faceless Content Workflow", "Voice Editing", "Assignment"] },
      { title: "Shorts Video Editing Mastery", items: ["Professional Editing Workflow", "Subtitle & Animation Setup", "Smooth Transition Effects", "Copyright Free Content System", "Mobile & PC Editing Method", "Assignment"] },
      { title: "Growth, Monetization & YouTube Strategy", items: ["Shorts Algorithm Strategy", "Viral Upload Method", "YouTube Monetization System", "Adsense & Income Strategy", "YouTube Guidelines & Copyright Rules", "Long-Term Growth Strategy"] },
    ],
    features: ["Live Classes", "Class Recording Provided", "Weekly Support Session", "Beginner Friendly Training", "Practical Learning System", "Community Support", "Step-by-Step Guidance", "Certificate"],
    reviewVideos: [
      "https://github.com/amarprio/MC-Audio_Files/raw/refs/heads/main/Student%20review.mp4",
      "https://github.com/amarprio/MC-Audio_Files/raw/refs/heads/main/Student%20review%20(2).mp4",
    ],
    reviews: [
      { name: "শাকিল আহমেদ", role: "USA Shorts স্টুডেন্ট", text: "৩০ দিনের চ্যালেঞ্জ ফলো করেই আমার শর্টস চ্যানেল মনিটাইজ হয়েছে। স্টেপ-বাই-স্টেপ গাইডলাইন অসাধারণ।", rating: 5 },
      { name: "ইমরান হোসেন", role: "USA Shorts স্টুডেন্ট", text: "ফেসলেস কন্টেন্ট তৈরির পুরো প্রসেস এত সহজভাবে শেখানো হয়েছে যে প্রথম মাসেই ভালো ভিউ পেয়েছি।", rating: 5 },
      { name: "জান্নাত আরা", role: "USA Shorts স্টুডেন্ট", text: "USA মার্কেট টার্গেট করার সঠিক কৌশল এই কোর্সে পেয়েছি। CPM এখন অনেক ভালো।", rating: 5 },
      { name: "তৌহিদুল ইসলাম", role: "USA Shorts স্টুডেন্ট", text: "AI ভয়েসওভার আর এডিটিং পার্টটা সবচেয়ে কাজে দিয়েছে। প্র্যাকটিক্যাল অ্যাসাইনমেন্টগুলো দারুণ।", rating: 5 },
      { name: "রাশেদুল করিম", role: "USA Shorts স্টুডেন্ট", text: "লাইফটাইম সাপোর্ট পাওয়াটা সত্যিই বড় সুবিধা। যেকোনো সমস্যায় দ্রুত সমাধান পাই।", rating: 5 },
      { name: "ফারিয়া তাবাসসুম", role: "USA Shorts স্টুডেন্ট", text: "শূন্য থেকে শুরু করে এখন নিজের একটা প্রফেশনাল শর্টস চ্যানেল আছে। ধন্যবাদ CreatorHaat।", rating: 5 },
    ],
  },
  {
    slug: "youtube-monetization",
    path: "/course/youtube-monetization",
    title: "YouTube Monetization and CPM Course",
    shortTitle: "YouTube Monetization & CPM",
    description:
      "এই কোর্সে শেখানো হবে কীভাবে বাংলাদেশ থেকে AI-powered English Content ব্যবহার করে USA মার্কেট টার্গেট করে YouTube চ্যানেল গ্রো, Monetization এবং High RPM অর্জন করা যায় — সম্পূর্ণ Step-by-Step প্রফেশনাল গাইডলাইনের মাধ্যমে।",
    regularPrice: 4999,
    offerPrice: 1999,
    discount: 3000,
    image: course2Img.url,
    youtubeId: "QgZMkBpLT_s",
    whyTake: [
      "কম সময়, বেশি আয় – মাত্র কিছু সেটআপের মাধ্যমে আপনি ঘরে বসেই ইউটিউব থেকে আয় শুরু করতে পারবেন।",
      "ফুল অটোমেটেড সিস্টেম – ভিডিও তৈরি, আপলোড ও মনিটাইজেশন সবই অটোমেশন, তাই আপনার সময় বাঁচে।",
      "নিশ্চিত মার্কেট – মার্কিন দর্শক এবং ইউএস-ভিত্তিক নিসে চ্যানেল তৈরি করার সিস্টেম, যেখানে রেভিনিউ রেট সর্বদা বেশি।",
      "ভাইরাল হওয়া সহজ – প্রুফড অটোমেশন প্রসেস ব্যবহার করে ভিডিও খুব সহজে ভাইরাল হবে।",
      "বাড়তি ইনকাম সোর্স – এটা শুধু ইউটিউব চ্যানেল নয়, আপনার প্যাসিভ আয়ের এক শক্তিশালী মাধ্যম।",
      "ফ্রিল্যান্স বা ফুলটাইম ব্যবসা – নিজের টাইম অনুযায়ী কাজ করতে পারবেন, ২৪/৭ আয়ের সুযোগ।",
    ],
    outline: [
      { title: "Channel Setup & Foundation", items: [
        "YouTube Channel Create and Setup",
        "Faceless Channel",
        "High RPM YT Automation (USA Targeted)",
      ]},
      { title: "Content Ideas & AI Creation", items: [
        "Video Idea Generation",
        "Unlimited AI Content Creation",
        "Advanced Prompt Engineering",
        "70+ Secret Niches for YouTube Success",
      ]},
      { title: "Viral Thumbnail & Shorts", items: [
        "Create Viral Thumbnail",
        "How To Make Viral Shorts",
      ]},
      { title: "Video Editing Masterclass", items: [
        "Video Editing Masterclass",
      ]},
      { title: "Algorithm, SEO & Growth", items: [
        "Secrets of YT Algorithm & Viral",
        "YT Secrets SEO",
      ]},
      { title: "Monetization & Guidelines", items: [
        "How To Monetize",
        "YT Guidelines & Fair Use Secrets",
      ]},
      { title: "Final Masterclass", items: [
        "FINAL MASTERCLASS – Endless Opportunities and Secret Tricks",
      ]},
    ],
    features: ["Live Classes", "Class Recording Provided", "Weekly Support Session", "Beginner Friendly Training", "Practical Learning System", "Community Support", "Step-by-Step Guidance", "Certificate"],
    reviewVideos: [
      "https://github.com/amarprio/MC-Audio_Files/raw/refs/heads/main/Student%20review.mp4",
      "https://github.com/amarprio/MC-Audio_Files/raw/refs/heads/main/Student%20review%20(2).mp4",
    ],
    reviews: [
      { name: "মাহমুদুল হাসান", role: "YT Monetization স্টুডেন্ট", text: "AI-powered English কন্টেন্ট দিয়ে USA টার্গেট করে চ্যানেল গ্রো করার যে সিস্টেম শেখানো হয়েছে — এটাই গেম-চেঞ্জার।", rating: 5 },
      { name: "সাব্বির রহমান", role: "YT Monetization স্টুডেন্ট", text: "High RPM নিস রিসার্চ পার্টটা সবচেয়ে ভালো লেগেছে। এখন প্রতি মাসে আয় দ্বিগুণ হয়েছে।", rating: 5 },
      { name: "রুবিনা আক্তার", role: "YT Monetization স্টুডেন্ট", text: "মনিটাইজেশন আর Adsense সেটআপ সম্পূর্ণ ক্লিয়ার করে দেওয়া হয়েছে। শুভ ভাইয়ের শেখানোর স্টাইল অসাধারণ।", rating: 5 },
      { name: "নাহিদুর রহমান", role: "YT Monetization স্টুডেন্ট", text: "ভাইরাল থাম্বনেইল আর SEO সিক্রেট জানার পর আমার ভিডিওর CTR অনেক বেড়েছে।", rating: 5 },
      { name: "তামান্না জাহান", role: "YT Monetization স্টুডেন্ট", text: "৭০+ সিক্রেট নিস আইডিয়া পাওয়াটা ছিল আমার জন্য আশীর্বাদ। নিজের পছন্দের নিস বেছে নিতে পেরেছি।", rating: 5 },
      { name: "আরিফ মাহমুদ", role: "YT Monetization স্টুডেন্ট", text: "ফেসলেস চ্যানেল আর অটোমেশনের পুরো ওয়ার্কফ্লো এত সহজে শেখানো হবে ভাবিনি। সত্যিই প্যাসিভ ইনকাম এখন বাস্তব।", rating: 5 },
    ],
  },
];

export const FAQS = [
  { q: "কোর্সটি লাইভ নাকি রেকর্ডেড?", a: "কোর্সটি সম্পূর্ণ লাইভ ক্লাস।" },
  { q: "ক্লাস রেকর্ড দেয়া হবে কি?", a: "হ্যাঁ, প্রতিটি লাইভ ক্লাস শেষে তার রেকর্ডিং দেওয়া হবে।" },
  { q: "কোর্স করার জন্য আগে থেকে কী জানতে হবে?", a: "আপনার ইউটিউব সম্পর্কে সামান্য ধারণা থাকলেই হবে।" },
  { q: "কোর্স কেনার পর আবার কোনো টাকা লাগবে কি না?", a: "না, একবার কোর্সে ভর্তি হলে আর কোনো অতিরিক্ত টাকা লাগবে না।" },
  { q: "অর্ডার করার পর কিভাবে ক্লাসে যোগ দেব?", a: "পেমেন্ট সম্পন্ন হওয়ার পর সিস্টেম থেকে স্বয়ংক্রিয়ভাবে একটি ইমেইল পাঠানো হবে, যেখানে অফিসিয়াল WhatsApp গ্রুপের লিংক ও নির্দেশনা থাকবে।" },
  { q: "কোর্স ফি কীভাবে পরিশোধ করব?", a: "“Enroll Now” বাটনে ক্লিক করে বিকাশ, নগদ অথবা রকেটে সহজেই পেমেন্ট সম্পন্ন করতে পারবেন।" },
  { q: "কোর্সে যে টুলসগুলো লাগবে, সেগুলোর সাবস্ক্রিপশন আলাদাভাবে নিতে হবে কি?", a: "না, সবগুলো প্রয়োজনীয় টুলস আমরা প্রোভাইড করব। এগুলো দিয়ে আপনি আনলিমিটেড কাজ করতে পারবেন।" },
  { q: "এই কোর্স করলে কত দিনের মধ্যে ইনকাম শুরু হবে?", a: "আমাদের প্রসেস ফলো করে নিয়মিত কাজ করলে ১-২ মাসের মধ্যেই ভালো রেজাল্ট আসবে ইনশাআল্লাহ।" },
  { q: "আপনারা কতদিন সাপোর্ট করবেন?", a: "ইনকাম না হওয়া পর্যন্ত আমাদের সাপোর্ট টিম থেকে হেল্প নিতে পারবেন ইনশাআল্লাহ।" },
  { q: "কোর্সের মেয়াদ কত দিন?", a: "লাইফটাইম অ্যাক্সেস।" },
];

export const REVIEWS = [
  { name: "রাকিব হাসান", role: "USA Shorts স্টুডেন্ট", text: "মাত্র ২ মাসে আমার চ্যানেল মনিটাইজ হয়েছে। CreatorHaat-এর গাইডলাইন অসাধারণ। লাইভ ক্লাসে যেকোনো প্রশ্নের সরাসরি উত্তর পাই।", rating: 5 },
  { name: "ফাহিম আহমেদ", role: "YouTube Automation স্টুডেন্ট", text: "শূন্য থেকে শুরু করেছিলাম, এখন প্রতি মাসে ভালো ইনকাম হচ্ছে আলহামদুলিল্লাহ। স্যারদের সাপোর্ট সত্যিই অসাধারণ।", rating: 5 },
  { name: "তানভীর ইসলাম", role: "ভিডিও এডিটিং স্টুডেন্ট", text: "একদম প্র্যাকটিক্যাল কোর্স। প্রতিটি ক্লাস শেষে অ্যাসাইনমেন্ট আর ফিডব্যাক — এটাই আমাকে দক্ষ করে তুলেছে।", rating: 5 },
  { name: "সাদিয়া আক্তার", role: "USA Shorts স্টুডেন্ট", text: "মেয়ে হয়েও ঘরে বসে ইনকাম করতে পারছি এই কোর্সের কারণে। সবাইকে রিকমেন্ড করব।", rating: 5 },
  { name: "মেহেদী হাসান", role: "YT Monetization স্টুডেন্ট", text: "শুভ ভাইয়ের শেখানোর স্টাইল খুবই সহজ ও স্পষ্ট। লাইফটাইম সাপোর্ট পাওয়াটা বড় প্লাস পয়েন্ট।", rating: 5 },
  { name: "নাঈম উদ্দিন", role: "Automation স্টুডেন্ট", text: "AI দিয়ে কনটেন্ট বানানো শিখেছি এবং সত্যিই আমার চ্যানেল গ্রো করছে। ধন্যবাদ CreatorHaat টিম।", rating: 5 },
];

export const CHANNEL_SCREENSHOTS = [
  ss8.url, ss16.url, ss6.url, ss10.url, ss17.url, ss12.url, ss4.url, ss3.url, ss9.url, ss7.url,
];
