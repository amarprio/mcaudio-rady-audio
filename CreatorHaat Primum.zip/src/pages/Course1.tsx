import { COURSES } from "@/lib/data";
import CoursePage from "@/components/CoursePage";
export default function Course1() { return <CoursePage course={COURSES[0]} />; }
