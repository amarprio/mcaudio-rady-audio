import { COURSES } from "@/lib/data";
import CoursePage from "@/components/CoursePage";
export default function Course2() { return <CoursePage course={COURSES[1]} />; }
