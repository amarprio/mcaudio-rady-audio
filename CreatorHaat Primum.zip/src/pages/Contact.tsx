import { Mail, Phone, MapPin, MessageCircle } from "lucide-react";
import { EMAIL, PHONE_DISPLAY, WHATSAPP_LINK } from "@/lib/data";
import SEO from "@/components/SEO";

export default function Contact() {
  return (
    <section className="section border-0 py-10 md:py-14 px-0">
      <SEO
        title="যোগাযোগ — CreatorHaat"
        description="CreatorHaat-এর সাথে যোগাযোগ করুন — WhatsApp, ইমেইল বা ফোনে। কোর্স এবং সাপোর্টের যেকোনো প্রশ্নের দ্রুত উত্তর পান।"
        path="/contact"
      />
      <div className="container-x max-w-4xl">
        <h1 className="section-title">Get in Touch</h1>
        <p className="section-sub">যেকোনো প্রশ্ন বা সহায়তার জন্য আমাদের সাথে যোগাযোগ করুন</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="card text-center hover:border-[var(--brand-red)] border-2 border-transparent">
            <div className="w-14 h-14 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto mb-3"><MessageCircle size={26} /></div>
            <h3 className="font-bold text-[var(--brand-navy)]">WhatsApp</h3>
            <p className="text-sm text-slate-600 mt-1">{PHONE_DISPLAY}</p>
          </a>
          <a href={`mailto:${EMAIL}`} className="card text-center hover:border-[var(--brand-red)] border-2 border-transparent">
            <div className="w-14 h-14 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-3"><Mail size={26} /></div>
            <h3 className="font-bold text-[var(--brand-navy)]">Email</h3>
            <p className="text-sm text-slate-600 mt-1 break-all">{EMAIL}</p>
          </a>
          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="card text-center hover:border-[var(--brand-red)] border-2 border-transparent">
            <div className="w-14 h-14 rounded-full bg-orange-100 text-[var(--brand-red)] flex items-center justify-center mx-auto mb-3"><Phone size={26} /></div>
            <h3 className="font-bold text-[var(--brand-navy)]">Phone</h3>
            <p className="text-sm text-slate-600 mt-1">{PHONE_DISPLAY}</p>
          </a>
        </div>
        <div className="card mt-6 flex items-start gap-3">
          <MapPin className="text-[var(--brand-red)] shrink-0 mt-1" />
          <div>
            <h3 className="font-bold text-[var(--brand-navy)]">Location</h3>
            <p className="text-sm text-slate-600">Naogaon Sadar, Rajshahi, Dhaka, Bangladesh</p>
          </div>
        </div>
      </div>
    </section>
  );
}
