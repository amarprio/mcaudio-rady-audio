import { Link, useLocation } from "react-router-dom";
import { CheckCircle2, MessageCircle, Mail, Phone } from "lucide-react";
import { BKASH, NAGAD, WHATSAPP_LINK, EMAIL, PHONE_DISPLAY } from "@/lib/data";
import SEO from "@/components/SEO";

export default function ThankYou() {
  const { state } = useLocation() as { state?: { course?: string; amount?: number; name?: string } };
  return (
    <section className="section bg-[var(--bg-soft)] min-h-[80vh]">
      <SEO title="ধন্যবাদ — CreatorHaat" description="আপনার এনরোলমেন্ট রিকোয়েস্ট সফলভাবে গ্রহণ করা হয়েছে।" path="/thank-you" noindex />
      <div className="container-x max-w-2xl">
        <div className="card text-center">
          <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-5 floaty">
            <CheckCircle2 size={48} className="text-green-600" />
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold text-[var(--brand-navy)] mb-3">ধন্যবাদ {state?.name || ""}! 🎉</h1>
          <p className="text-slate-600 mb-2">আপনার এনরোলমেন্ট রিকোয়েস্ট আমরা পেয়েছি।</p>
          {state?.course && <p className="text-sm text-slate-700"><b>{state.course}</b> {state.amount ? `— ৳${state.amount}` : ""}</p>}

          <div className="mt-6 text-left bg-orange-50 border border-orange-200 rounded-xl p-5">
            <h3 className="font-bold text-[var(--brand-red)] mb-3">পরবর্তী ধাপসমূহ:</h3>
            <ol className="space-y-2 text-sm text-slate-700 list-decimal pl-5">
              <li>উপরের ফর্মে আপনার তথ্য সাবমিট করেছেন ✅</li>
              <li>এখন <b>বিকাশ ({BKASH})</b> অথবা <b>নগদ ({NAGAD})</b> পার্সোনাল নম্বরে কোর্স ফি সেন্ড মানি করুন।</li>
              <li>সেন্ড মানি করার পর WhatsApp এ আমাদের ম্যাসেজ পাঠান (নিচের বাটনে চাপ দিন)।</li>
              <li>আমাদের টিম যাচাই করে আপনাকে WhatsApp গ্রুপে এড করে দেবে।</li>
              <li>প্রথম লাইভ ক্লাসের সময়সূচি জানিয়ে দেওয়া হবে।</li>
            </ol>
          </div>

          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="mt-6 inline-flex items-center gap-2 bg-[#25d366] text-white font-bold px-6 py-3 rounded-full hover:opacity-90 transition">
            <MessageCircle size={20} /> WhatsApp এ যোগাযোগ করুন
          </a>

          <div className="mt-6 pt-6 border-t border-slate-200 flex flex-wrap justify-center gap-5 text-sm text-slate-600">
            <a href={`mailto:${EMAIL}`} className="flex items-center gap-2 hover:text-[var(--brand-red)]"><Mail size={16} /> {EMAIL}</a>
            <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-[var(--brand-red)]"><Phone size={16} /> {PHONE_DISPLAY}</a>
          </div>

          <Link to="/" className="block mt-6 text-sm text-[var(--brand-blue)] hover:underline">← হোমে ফিরে যান</Link>
        </div>
      </div>
    </section>
  );
}
