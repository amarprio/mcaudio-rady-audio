import { Link } from "react-router-dom";
import { MENTOR_URL, COURSES } from "@/lib/data";
import YouTubeEmbed from "@/components/YouTubeEmbed";
import ReviewSection from "@/components/ReviewSection";
import ChannelScreenshots from "@/components/ChannelScreenshots";
import SEO from "@/components/SEO";
import { Award, Target, BookOpen, Flame, Rocket, CheckCircle2, Users, Trophy, Star } from "lucide-react";

export default function Home() {
  return (
    <>
      <SEO
        title="CreatorHaat — YouTube Automation, USA Shorts ও Monetization কোর্স"
        description="বাংলাদেশের আধুনিক স্কিল ডেভেলপমেন্ট প্ল্যাটফর্ম CreatorHaat-এ শিখুন YouTube Automation, USA Shorts ও Monetization — লাইভ ক্লাস, প্র্যাকটিক্যাল অ্যাসাইনমেন্ট ও লাইফটাইম সাপোর্টের সাথে।"
        path="/"
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "EducationalOrganization",
          name: "CreatorHaat",
          url: "/",
          description: "YouTube Automation, USA Shorts ও Monetization কোর্স।",
        }}
      />
      {/* HERO */}
      <section className="hero-bg">
        <div className="container-x py-12 md:py-20 grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div className="anim-up text-center lg:text-left order-1 contents lg:block">
            <div className="order-1 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 bg-orange-100 text-[var(--brand-red)] px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
                🔥 নতুন ব্যাচে ভর্তি চলছে
              </div>
              <h1 className="font-display text-3xl md:text-5xl lg:text-6xl text-[var(--brand-navy)] leading-tight">
                নিজের স্বপ্নকে বাস্তবে রূপ দিতেই - <span className="gradient-text">CreatorHaat</span>
              </h1>
              <p className="mt-5 text-base md:text-lg text-slate-600 max-w-xl mx-auto lg:mx-0">
                সফলতা কখনো ভাগ্যের উপহার নয়, এটি তৈরি হয় দক্ষতা, পরিশ্রম এবং সঠিক সিদ্ধান্তের মাধ্যমে। আজই শুরু করুন আপনার স্কিল ডেভেলপমেন্ট যাত্রা।
              </p>
            </div>
            <div className="order-3 lg:order-2">
              <div className="mt-7 flex flex-wrap gap-3 justify-center lg:justify-start">
                <Link to="/courses" className="btn-primary">কোর্স দেখুন →</Link>
                <Link to="/about" className="btn-secondary">আমাদের সম্পর্কে</Link>
              </div>
              <div className="mt-8 flex flex-wrap gap-6 justify-center lg:justify-start text-sm text-slate-600">
                <div className="flex items-center gap-2"><Users size={18} className="text-[var(--brand-blue)]" /> ৫০০০+ স্টুডেন্ট</div>
                <div className="flex items-center gap-2"><Star size={18} fill="#fbbf24" stroke="#fbbf24" /> 4.9/5 রেটিং</div>
                <div className="flex items-center gap-2"><Trophy size={18} className="text-[var(--brand-red)]" /> লাইফটাইম সাপোর্ট</div>
              </div>
            </div>
          </div>
          <div className="anim-up-2 order-2 lg:order-2">
            <YouTubeEmbed id="QgZMkBpLT_s" autoplay title="CreatorHaat Intro" />
          </div>
        </div>
      </section>

      {/* CATEGORY */}
      <section className="section border-0 py-10 md:py-14 px-0">
        <div className="container-x">
          <h2 className="section-title">আপনার জন্য সেরা ক্যাটাগরি</h2>
          <p className="section-sub">নিজেকে দক্ষ করে তোলার সিদ্ধান্তই হতে পারে আপনার জীবনের সবচেয়ে বড় পরিবর্তন। স্বপ্নকে বাস্তবে রূপ দেওয়ার উপযুক্ত সময় এখনই।</p>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {[
              { name: "Facebook Automation", color: "#1877F2", icon: <FacebookIcon /> },
              { name: "YouTube Automation", color: "#FF0000", icon: <YouTubeIcon /> },
              { name: "USA Shorts Automation", color: "#FF0033", icon: <ShortsIcon /> },
              { name: "Video Editing", color: "#7C3AED", icon: <EditIcon /> },
            ].map((c, i) => (
              <div key={i} className="card text-center anim-up" style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl mx-auto flex items-center justify-center mb-4" style={{ background: `${c.color}15` }}>
                  {c.icon}
                </div>
                <h3 className="font-bold text-[var(--brand-navy)]">{c.name}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AJKER SKILL */}
      <section className="section border-0 py-10 md:py-14 px-0 bg-[var(--bg-soft)]">
        <div className="container-x text-center anim-up">
          <h2 className="section-title">আজকের স্কিল, <span className="gradient-text">আগামী দিনের সফলতা</span></h2>
          <p className="section-sub">শুধু স্বপ্ন দেখলেই হবে না, সফলতার জন্য নিজেকে দক্ষ করে গড়ে তুলতে হবে। ভবিষ্যতের জন্য প্রস্তুতি শুরু হোক আজই।</p>
        </div>
      </section>

      {/* COURSES */}
      <section className="section border-0 py-10 md:py-14 px-0">
        <div className="container-x">
          <h2 className="section-title">আমাদের কোর্সসমূহ</h2>
          <p className="section-sub">প্রফেশনাল গাইডলাইনে শিখুন এবং নিজের ক্যারিয়ার গড়ুন</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {COURSES.map((c, i) => (
              <div key={c.slug} className="card overflow-hidden p-0 anim-up" style={{ animationDelay: `${i * 0.1}s` }}>
                <Link to={c.path} className="block aspect-square md:aspect-[4/3] overflow-hidden">
                  <img src={c.image} alt={c.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                </Link>
                <div className="p-5">
                  <Link to={c.path}><h3 className="font-bold text-lg text-[var(--brand-navy)] mb-2 hover:text-[var(--brand-red)] transition">{c.title}</h3></Link>
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-slate-400 line-through">৳{c.regularPrice}</span>
                    <span className="text-2xl font-extrabold text-[var(--brand-red)]">৳{c.offerPrice}</span>
                  </div>
                  <Link to={c.path} className="btn-primary w-full justify-center">বিস্তারিত দেখুন</Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4 STEPS */}
      <section className="section border-0 py-10 md:py-14 px-0 bg-gradient-to-br from-[var(--brand-navy)] to-[#1e3a5f] text-white">
        <div className="container-x">
          <h2 className="section-title text-white">এগিয়ে যাও সফলতার পথে</h2>
          <p className="section-sub text-slate-300">মাত্র ৪টি ধাপে শুরু হোক আপনার স্কিল ডেভেলপমেন্ট ও সফল ক্যারিয়ারের যাত্রা।</p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
            {[
              { icon: <Target size={28} />, t: "লক্ষ্য ঠিক করুন" },
              { icon: <BookOpen size={28} />, t: "সঠিক কোর্স বেছে নিন" },
              { icon: <Flame size={28} />, t: "নিয়মিত প্র্যাকটিস করুন" },
              { icon: <Rocket size={28} />, t: "দক্ষতা দিয়ে ক্যারিয়ার শুরু করুন" },
            ].map((s, i) => (
              <div key={i} className="bg-white/10 backdrop-blur p-6 rounded-2xl border border-white/10 anim-up" style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[var(--brand-red)] to-[var(--brand-orange)] flex items-center justify-center mb-4">{s.icon}</div>
                <div className="text-sm text-slate-300 mb-1">ধাপ {i + 1}</div>
                <h3 className="font-bold text-lg">{s.t}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INSTRUCTOR */}
      <section className="section border-0 py-10 md:py-14 px-0">
        <div className="container-x">
          <h2 className="section-title">CreatorHaat Team</h2>
          <p className="section-sub">Our Expert Instructors</p>
          <div className="max-w-[280px] md:max-w-[360px] mx-auto">
            <div className="card text-center overflow-hidden p-0">
              <div className="aspect-square overflow-hidden bg-slate-100">
                <img src={MENTOR_URL} alt="Shuvo Mondal" className="w-full h-full object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-[var(--brand-navy)]">Shuvo Mondal</h3>
                <p className="text-sm text-[var(--brand-red)] font-semibold mt-1">Owner & Trainer — YouTube Expert</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MISSION */}
      <section className="section border-0 py-10 md:py-14 px-0 bg-[var(--bg-soft)]">
        <div className="container-x max-w-4xl text-center">
          <h2 className="section-title">CreatorHaat-এর লক্ষ্য কী?</h2>
          <p className="text-slate-600 text-lg leading-relaxed mb-8">
            CreatorHaat একটি আধুনিক অনলাইনভিত্তিক স্কিল ডেভেলপমেন্ট প্ল্যাটফর্ম, যেখানে তরুণদের বর্তমান যুগের চাহিদাসম্পন্ন ডিজিটাল স্কিল ও ক্যারিয়ারমুখী দক্ষতা অর্জনে সহায়তা করা হয়। আমাদের প্র্যাকটিক্যাল ও সহজবোধ্য কোর্সগুলো এমনভাবে তৈরি করা হয়েছে, যাতে শিক্ষার্থীরা শুধু তাত্ত্বিক জ্ঞান নয়, বাস্তব অভিজ্ঞতা ও কার্যকর দক্ষতা অর্জন করতে পারে।
          </p>
          <a href="https://www.creatorhaat.com/courses/" target="_blank" rel="noreferrer" className="btn-primary">সফলতার পথে যুক্ত হোন →</a>
        </div>
      </section>

      {/* DAKKHATA */}
      <section className="section border-0 py-10 md:py-14 px-0 text-center bg-gradient-to-br from-[var(--brand-red)] to-[var(--brand-orange)] text-white">
        <div className="container-x max-w-3xl">
          <h2 className="text-3xl md:text-4xl font-extrabold mb-3">দক্ষতাই হোক, তোমার সফলতার পরিচয়</h2>
          <p className="text-white/90 text-lg mb-6">বর্তমান যুগে এগিয়ে থাকতে চাইলে প্রয়োজন বাস্তব দক্ষতা। শিখো, নিজেকে গড়ো এবং এগিয়ে যাও আত্মবিশ্বাসের সাথে।</p>
          <a href="https://www.creatorhaat.com/courses/" target="_blank" rel="noreferrer" className="btn-yellow">স্বপ্নের ক্যারিয়ার শুরু হোক →</a>
        </div>
      </section>

      {/* WHY TRUST */}
      <section className="section border-0 py-10 md:py-14 px-0">
        <div className="container-x">
          <h2 className="section-title">কেন আমাদের উপর আস্থা রাখবেন?</h2>
          <p className="section-sub">হাজারো শিক্ষার্থীর শেখা ও সফলতার বিশ্বস্ত প্ল্যাটফর্ম</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[
              { icon: <Award size={26} />, t: "প্র্যাকটিক্যাল লার্নিং সিস্টেম", d: "ক্যারিয়ার ও স্কিল ডেভেলপমেন্টের জন্য সাজানো সম্পূর্ণ প্র্যাকটিক্যাল লার্নিং সিস্টেম।" },
              { icon: <Users size={26} />, t: "এক্সপার্ট মেন্টর", d: "বাস্তব অভিজ্ঞতাসম্পন্ন এক্সপার্টদের গাইডলাইনে সহজ ও ইন্ডাস্ট্রি-রেডি শেখার সুযোগ।" },
              { icon: <CheckCircle2 size={26} />, t: "কুইজ ও সার্টিফিকেট", d: "প্রতিটি কোর্সে রয়েছে কুইজ, এসাইনমেন্ট ও সার্টিফিকেটের সুবিধা।" },
            ].map((x, i) => (
              <div key={i} className="card">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[var(--brand-blue)] to-[var(--brand-cyan)] text-white flex items-center justify-center mb-4">{x.icon}</div>
                <h3 className="font-bold text-lg text-[var(--brand-navy)] mb-2">{x.t}</h3>
                <p className="text-slate-600 text-sm">{x.d}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            {[{n:"5000+", l:"স্টুডেন্ট"},{n:"50+", l:"লাইভ ব্যাচ"},{n:"4.9★", l:"রেটিং"},{n:"100%", l:"লাইফটাইম সাপোর্ট"}].map((s,i)=>(
              <div key={i} className="bg-gradient-to-br from-[var(--brand-navy)] to-[#1e3a5f] text-white rounded-2xl p-5">
                <div className="text-3xl font-extrabold gradient-text">{s.n}</div>
                <div className="text-sm text-slate-300 mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <ReviewSection />
      <ChannelScreenshots />
    </>
  );
}

function FacebookIcon() { return <svg width="40" height="40" viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.1 10.13 24v-8.44H7.08v-3.49h3.05V9.41c0-3.02 1.79-4.69 4.53-4.69 1.31 0 2.69.24 2.69.24v2.97h-1.52c-1.49 0-1.95.93-1.95 1.89v2.26h3.33l-.53 3.49h-2.8V24C19.61 23.1 24 18.1 24 12.07"/></svg>; }
function YouTubeIcon() { return <svg width="44" height="32" viewBox="0 0 24 24" fill="#FF0000"><path d="M23.5 6.2a3 3 0 00-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 00.5 6.2 31 31 0 000 12a31 31 0 00.5 5.8 3 3 0 002.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 002.1-2.1A31 31 0 0024 12a31 31 0 00-.5-5.8zM9.6 15.6V8.4l6.2 3.6-6.2 3.6z"/></svg>; }
function ShortsIcon() { return <svg width="36" height="42" viewBox="0 0 24 28" fill="#FF0033"><path d="M17.77 9.43L9.92 5.05a4.7 4.7 0 00-6.62 2 4.78 4.78 0 002 6.65l.96.54-.96.53a4.78 4.78 0 00-2 6.65 4.7 4.7 0 006.62 2l7.85-4.38a4.78 4.78 0 000-8.39z"/><path d="M10 18.5V9.5l7 4.5-7 4.5z" fill="#fff"/></svg>; }
function EditIcon() { return <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#7C3AED" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>; }
