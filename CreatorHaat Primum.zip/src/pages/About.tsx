import { Link } from "react-router-dom";
import { MENTOR_URL } from "@/lib/data";
import { CheckCircle2 } from "lucide-react";
import SEO from "@/components/SEO";

export default function About() {
  return (
    <>
      <SEO
        title="আমাদের সম্পর্কে — CreatorHaat"
        description="CreatorHaat সম্পর্কে জানুন — বাংলাদেশের আধুনিক স্কিল ডেভেলপমেন্ট প্ল্যাটফর্ম। লাইভ ক্লাস, বাস্তব প্রজেক্ট এবং ইন্ডাস্ট্রি-রেডি স্কিলে গড়ুন সফল ক্যারিয়ার।"
        path="/about"
      />
      <section className="hero-bg">
        <div className="container-x py-12 text-center">
          <h1 className="font-display text-3xl md:text-5xl text-[var(--brand-navy)]">CreatorHaat</h1>
          <p className="mt-3 text-lg text-slate-600">Learn Live • Build Skills • Grow Your Career</p>
          <p className="mt-4 max-w-2xl mx-auto text-slate-600">লাইভ ক্লাস, বাস্তব প্রজেক্ট এবং ইন্ডাস্ট্রি-রেডি স্কিলের মাধ্যমে তরুণদের দক্ষ করে তুলতেই CreatorHaat এর যাত্রা। আমরা বিশ্বাস করি — সঠিক গাইডলাইন + ধারাবাহিক প্র্যাকটিস + বাস্তব অভিজ্ঞতা = সফল ক্যারিয়ার।</p>
          <div className="mt-4 inline-block bg-yellow-100 text-yellow-800 px-4 py-2 rounded-full text-sm font-bold">4.9/5 শিক্ষার্থীদের আস্থা ⭐</div>
        </div>
      </section>

      <section className="section border-0 py-10 md:py-14 px-0">
        <div className="container-x max-w-4xl">
          <h2 className="section-title">আমাদের সম্পর্কে</h2>
          <p className="text-slate-700 leading-relaxed mb-4">CreatorHaat বাংলাদেশের একটি আধুনিক ও বিশ্বস্ত স্কিল ডেভেলপমেন্ট প্ল্যাটফর্ম, যেখানে ইন্ডাস্ট্রি-এক্সপার্ট মেন্টরদের মাধ্যমে লাইভ ক্লাস, প্র্যাকটিক্যাল অ্যাসাইনমেন্ট এবং বাস্তবমুখী প্রজেক্টের সাহায্যে শিক্ষার্থীদের ক্যারিয়ার-রেডি করে তোলা হয়।</p>
          <p className="text-slate-700 leading-relaxed">আমাদের লক্ষ্য শুধু কোর্স করানো নয়, বরং এমন একটি দক্ষ প্রজন্ম তৈরি করা যারা বাস্তব কাজের মাধ্যমে নিজেদের ভবিষ্যৎ গড়ে তুলতে সক্ষম হবে।</p>
        </div>
      </section>

      <section className="section border-0 py-10 md:py-14 px-0 bg-[var(--bg-soft)]">
        <div className="container-x max-w-4xl">
          <h2 className="section-title">প্রতিটি লাইভ ব্যাচে থাকছে</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            {[
              "লাইভ ক্লাস + রেকর্ডিং অ্যাক্সেস",
              "প্র্যাকটিক্যাল প্রজেক্ট ও পোর্টফোলিও গাইড",
              "অ্যাসাইনমেন্ট ও পার্সোনাল ফিডব্যাক",
              "ক্যারিয়ার গাইডলাইন ও ইন্টারভিউ প্রস্তুতি",
              "সাপোর্টিভ কমিউনিটি ও মেন্টরশিপ",
              "ইন্ডাস্ট্রি-রেডি স্কিল ও আপডেটেড কারিকুলাম",
            ].map((x, i) => (
              <div key={i} className="card flex gap-3 items-start">
                <CheckCircle2 className="text-green-600 shrink-0 mt-1" size={20} />
                <span className="text-slate-700">{x}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section border-0 py-10 md:py-14 px-0">
        <div className="container-x">
          <h2 className="section-title">Our Mentor</h2>
          <div className="max-w-[240px] md:max-w-[300px] mx-auto card text-center overflow-hidden p-0">
            <div className="aspect-square overflow-hidden"><img src={MENTOR_URL} alt="Shuvo Mondal" className="w-full h-full object-cover" /></div>
            <div className="p-6">
              <h3 className="text-xl font-bold text-[var(--brand-navy)]">Shuvo Mondal</h3>
              <p className="text-sm text-[var(--brand-red)] font-semibold mt-1">Owner & Trainer — YouTube Expert</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section border-0 py-10 md:py-14 px-0 text-center bg-gradient-to-br from-[var(--brand-red)] to-[var(--brand-orange)] text-white">
        <div className="container-x max-w-2xl">
          <h2 className="text-3xl md:text-4xl font-extrabold mb-3">আজই শুরু হোক আপনার নতুন যাত্রা</h2>
          <p className="text-white/90 mb-6">নিজের পছন্দের স্কিল বেছে নিন, যুক্ত হোন লাইভ ব্যাচে।</p>
          <Link to="/courses" className="btn-yellow">Enroll Now →</Link>
        </div>
      </section>
    </>
  );
}
