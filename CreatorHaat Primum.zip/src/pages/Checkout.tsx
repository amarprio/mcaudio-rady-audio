import { useParams, useNavigate, Link } from "react-router-dom";
import { useState } from "react";
import { COURSES, BKASH, NAGAD, WHATSAPP_NUMBER } from "@/lib/data";
import Countdown from "@/components/Countdown";
import SEO from "@/components/SEO";
import { Copy, CheckCircle2, MessageCircle, User, CreditCard, Send, ArrowLeft, ShieldCheck } from "lucide-react";

type Step = 1 | 2 | 3;

export default function Checkout() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const course = COURSES.find(c => c.slug === slug) || COURSES[0];

  const [step, setStep] = useState<Step>(1);
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "" });
  const [payment, setPayment] = useState({ method: "bKash", senderNumber: "", trxId: "" });
  const [copied, setCopied] = useState<string | null>(null);

  const copy = (val: string, key: string) => {
    navigator.clipboard.writeText(val);
    setCopied(key);
    setTimeout(() => setCopied(null), 1500);
  };

  const isValidBDPhone = (v: string) => /^01[3-9]\d{8}$/.test(v.trim());

  const goStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      alert("দয়া করে আপনার নাম দিন।");
      return;
    }
    if (!isValidBDPhone(form.phone)) {
      alert("দয়া করে একটি বৈধ বাংলাদেশি মোবাইল নম্বর দিন (১১ ডিজিট, যেমন: 01XXXXXXXXX)।");
      return;
    }
    setStep(2);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const sendWA = () => {
    if (!isValidBDPhone(payment.senderNumber)) {
      alert("দয়া করে একটি বৈধ বাংলাদেশি সেন্ডার নম্বর দিন (১১ ডিজিট, যেমন: 01XXXXXXXXX)।");
      return;
    }
    if (!payment.trxId.trim()) {
      alert("ট্রানজেকশন আইডি (TrxID) দিন।");
      return;
    }
    const msg = encodeURIComponent(
`আসসালামু আলাইকুম, আমি পেমেন্ট সম্পন্ন করেছি ✅

📚 কোর্স: ${course.title}
💰 পরিমাণ: ${course.offerPrice}৳
💳 পেমেন্ট মেথড: ${payment.method}
🔢 সেন্ডার নম্বর: ${payment.senderNumber}
🧾 TrxID: ${payment.trxId}

👤 নাম: ${form.name}
📞 WhatsApp: ${form.phone}
📧 ইমেইল: ${form.email || "—"}
📍 ঠিকানা: ${form.address || "—"}

দয়া করে আমার এনরোল কনফার্ম করুন।`
    );
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, "_blank");
    setTimeout(() => navigate("/thank-you", {
      state: { course: course.title, amount: course.offerPrice, name: form.name, trxId: payment.trxId, method: payment.method }
    }), 500);
  };

  const steps = [
    { n: 1, t: "তথ্য দিন", icon: <User size={16} /> },
    { n: 2, t: "পেমেন্ট করুন", icon: <CreditCard size={16} /> },
    { n: 3, t: "কনফার্ম", icon: <Send size={16} /> },
  ];

  return (
    <section className="section bg-[var(--bg-soft)]">
      <SEO title={`চেকআউট — ${course.title}`} description="CreatorHaat কোর্স এনরোলমেন্ট চেকআউট পেজ।" path={`/checkout/${course.slug}`} noindex />
      <div className="container-x max-w-5xl">
        <div className="text-center mb-6">
          <h1 className="text-2xl md:text-3xl font-extrabold text-[var(--brand-navy)]">নিচের ধাপগুলো পূরণ করে এনরোল করুন</h1>
          <p className="text-sm text-slate-600 mt-2">⏰ অফার সীমিত সময়ের জন্য</p>
          <Countdown hours={9} />
        </div>

        {/* Stepper */}
        <div className="flex items-center justify-center gap-2 md:gap-4 mb-6">
          {steps.map((s, i) => (
            <div key={s.n} className="flex items-center gap-2 md:gap-4">
              <div className={`flex items-center gap-2 px-3 py-2 rounded-full text-xs md:text-sm font-bold transition ${step >= (s.n as Step) ? "bg-[var(--brand-red)] text-white" : "bg-white text-slate-500 border border-slate-200"}`}>
                {step > (s.n as Step) ? <CheckCircle2 size={16} /> : s.icon}
                <span className="hidden sm:inline">{s.t}</span>
                <span className="sm:hidden">{s.n}</span>
              </div>
              {i < steps.length - 1 && <div className={`w-6 md:w-12 h-0.5 ${step > (s.n as Step) ? "bg-[var(--brand-red)]" : "bg-slate-300"}`} />}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* LEFT */}
          <div className="lg:col-span-3 space-y-5">
            {step === 1 && (
              <div className="card">
                <h3 className="font-bold text-lg text-[var(--brand-navy)] mb-1">ধাপ ১ — ব্যক্তিগত তথ্য</h3>
                <p className="text-sm text-slate-500 mb-4">আপনার সঠিক তথ্য দিন, কোর্সের সব আপডেট এখানে পাঠানো হবে।</p>
                <form onSubmit={goStep2} className="space-y-4">
                  <div>
                    <label className="text-sm font-semibold text-slate-700 mb-1 block">সম্পূর্ণ নাম *</label>
                    <input type="text" required value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="আপনার পুরো নাম" />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-slate-700 mb-1 block">WhatsApp নাম্বার *</label>
                    <input type="tel" required inputMode="numeric" pattern="01[3-9][0-9]{8}" maxLength={11} value={form.phone} onChange={e => setForm({...form, phone: e.target.value.replace(/\D/g, "").slice(0, 11)})} placeholder="01XXXXXXXXX" title="বৈধ বাংলাদেশি মোবাইল নম্বর দিন (১১ ডিজিট)" />
                    {form.phone && !/^01[3-9]\d{8}$/.test(form.phone) && (
                      <p className="text-xs text-red-600 mt-1">বৈধ ১১-ডিজিটের মোবাইল নম্বর দিন (যেমন: 01XXXXXXXXX)</p>
                    )}
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-slate-700 mb-1 block">ইমেইল</label>
                    <input type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} placeholder="you@example.com" />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-slate-700 mb-1 block">ঠিকানা (ঐচ্ছিক)</label>
                    <input type="text" value={form.address} onChange={e => setForm({...form, address: e.target.value})} placeholder="জেলা / এলাকা" />
                  </div>
                  <button type="submit" className="btn-primary w-full justify-center">পেমেন্ট ধাপে যান →</button>
                </form>
              </div>
            )}

            {step === 2 && (
              <div className="card border-2 border-[var(--brand-red)]">
                <button onClick={() => setStep(1)} className="text-sm text-slate-500 flex items-center gap-1 mb-3 hover:text-[var(--brand-red)]"><ArrowLeft size={14} /> পিছনে</button>
                <h3 className="font-bold text-lg text-[var(--brand-navy)] mb-1">ধাপ ২ — সেন্ড মানি করুন</h3>
                <p className="text-sm text-slate-600 mb-4">নিচের যেকোনো নম্বরে <b className="text-[var(--brand-red)]">৳{course.offerPrice}</b> <b>Send Money</b> করুন (Personal):</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                  {[{ name: "bKash", num: BKASH, color: "#E2136E", bg: "#fce4ee" }, { name: "Nagad", num: NAGAD, color: "#F47216", bg: "#fff1e3" }].map((p) => (
                    <div key={p.name} className="p-4 rounded-xl border-2" style={{ borderColor: p.color, background: p.bg }}>
                      <div className="text-xs font-bold mb-1" style={{ color: p.color }}>{p.name} (Send Money)</div>
                      <div className="font-extrabold text-lg text-[var(--brand-navy)] mb-2">{p.num}</div>
                      <button onClick={() => { copy(p.num, p.name); setPayment(pm => ({...pm, method: p.name})); }} className="w-full bg-white text-sm font-bold py-2 rounded-lg flex items-center justify-center gap-2" style={{ color: p.color, border: `1px solid ${p.color}` }}>
                        {copied === p.name ? <><CheckCircle2 size={14} /> কপি হয়েছে</> : <><Copy size={14} /> কপি করুন</>}
                      </button>
                    </div>
                  ))}
                </div>

                <div className="bg-yellow-50 border border-yellow-200 text-yellow-900 text-sm p-3 rounded-lg mb-4">
                  <b>📌 নির্দেশনা:</b> Send Money সম্পন্ন করার পর নিচে পেমেন্ট তথ্য পূরণ করুন।
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-semibold text-slate-700 mb-1 block">পেমেন্ট মেথড *</label>
                    <div className="flex gap-2">
                      {["bKash", "Nagad"].map(m => (
                        <button key={m} type="button" onClick={() => setPayment({...payment, method: m})}
                          className={`flex-1 py-2 rounded-lg font-bold text-sm border-2 transition ${payment.method === m ? "border-[var(--brand-red)] bg-orange-50 text-[var(--brand-red)]" : "border-slate-200 text-slate-600"}`}>
                          {m}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-slate-700 mb-1 block">যে নম্বর থেকে পাঠিয়েছেন *</label>
                    <input type="tel" inputMode="numeric" pattern="01[3-9][0-9]{8}" maxLength={11} value={payment.senderNumber} onChange={e => setPayment({...payment, senderNumber: e.target.value.replace(/\D/g, "").slice(0, 11)})} placeholder="01XXXXXXXXX" title="বৈধ বাংলাদেশি মোবাইল নম্বর দিন (১১ ডিজিট)" />
                    {payment.senderNumber && !/^01[3-9]\d{8}$/.test(payment.senderNumber) && (
                      <p className="text-xs text-red-600 mt-1">বৈধ ১১-ডিজিটের মোবাইল নম্বর দিন (যেমন: 01XXXXXXXXX)</p>
                    )}
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-slate-700 mb-1 block">Transaction ID (TrxID) *</label>
                    <input type="text" value={payment.trxId} onChange={e => setPayment({...payment, trxId: e.target.value.toUpperCase()})} placeholder="যেমন: 8N7A6B5C4D" />
                    <p className="text-xs text-slate-500 mt-1">SMS-এ পাওয়া TrxID দিন।</p>
                  </div>
                </div>

                <button onClick={() => { if(!/^01[3-9]\d{8}$/.test(payment.senderNumber)){ alert("বৈধ বাংলাদেশি সেন্ডার নম্বর দিন (১১ ডিজিট)"); return; } if(!payment.trxId.trim()){ alert("TrxID দিন"); return; } setStep(3); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                  className="btn-primary w-full justify-center mt-5">কনফার্ম করুন →</button>
              </div>
            )}

            {step === 3 && (
              <div className="card border-2 border-[#25d366]">
                <div className="text-center mb-4">
                  <div className="w-16 h-16 mx-auto rounded-full bg-green-100 flex items-center justify-center mb-3">
                    <CheckCircle2 size={36} className="text-green-600" />
                  </div>
                  <h3 className="font-bold text-xl text-[var(--brand-navy)]">প্রায় শেষ! শুধু একটি ক্লিক বাকি</h3>
                  <p className="text-sm text-slate-600 mt-2">আপনার পেমেন্ট তথ্য অটো WhatsApp এ এডমিনকে পাঠাতে নিচের বাটনে ক্লিক করুন। এডমিন ১৫–৩০ মিনিটের মধ্যে আপনার এনরোল কনফার্ম করবেন।</p>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl text-sm space-y-1 mb-4">
                  <div className="flex justify-between"><span className="text-slate-500">কোর্স:</span><b className="text-right">{course.title}</b></div>
                  <div className="flex justify-between"><span className="text-slate-500">পরিমাণ:</span><b className="text-[var(--brand-red)]">৳{course.offerPrice}</b></div>
                  <div className="flex justify-between"><span className="text-slate-500">মেথড:</span><b>{payment.method}</b></div>
                  <div className="flex justify-between"><span className="text-slate-500">TrxID:</span><b>{payment.trxId}</b></div>
                  <div className="flex justify-between"><span className="text-slate-500">নাম:</span><b>{form.name}</b></div>
                  <div className="flex justify-between"><span className="text-slate-500">WhatsApp:</span><b>{form.phone}</b></div>
                </div>

                <button onClick={sendWA} className="w-full bg-[#25d366] text-white font-bold py-4 rounded-full flex items-center justify-center gap-2 hover:opacity-90 transition text-base shadow-lg">
                  <MessageCircle size={22} /> WhatsApp এ পাঠান ও এনরোল কনফার্ম করুন
                </button>
                <button onClick={() => setStep(2)} className="w-full mt-3 text-sm text-slate-500 hover:text-[var(--brand-red)]">← পেমেন্ট তথ্য এডিট করুন</button>

                <div className="flex items-center gap-2 justify-center mt-4 text-xs text-slate-500">
                  <ShieldCheck size={14} /> ১০০% সিকিওর — আপনার তথ্য শুধু এডমিন দেখবেন।
                </div>
              </div>
            )}
          </div>

          {/* RIGHT - Order */}
          <div className="lg:col-span-2">
            <div className="card sticky top-24">
              <h3 className="font-bold text-lg text-[var(--brand-navy)] mb-4">Your Order</h3>
              <div className="flex gap-3 pb-3 border-b border-slate-200">
                <img src={course.image} alt={course.title} className="w-20 h-20 object-cover rounded-lg" />
                <div className="flex-1">
                  <div className="text-sm font-bold text-[var(--brand-navy)] line-clamp-2">{course.title}</div>
                  <div className="text-xs text-slate-500 mt-1">পরিমাণ: 1</div>
                </div>
              </div>
              <div className="space-y-2 py-3 text-sm">
                <div className="flex justify-between"><span className="text-slate-500">Regular Price</span><span className="line-through text-slate-400">৳{course.regularPrice}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Discount</span><span className="text-green-600">-৳{course.discount}</span></div>
              </div>
              <div className="flex justify-between text-lg pt-3 border-t border-slate-200"><b>Total</b><b className="text-[var(--brand-red)]">৳{course.offerPrice}</b></div>
              <Link to={course.path} className="block text-center text-sm text-[var(--brand-blue)] mt-4 hover:underline">← কোর্স বিস্তারিত দেখুন</Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
