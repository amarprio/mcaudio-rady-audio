import { Link } from "react-router-dom";
import { COURSES } from "@/lib/data";
import SEO from "@/components/SEO";

export default function Courses() {
  return (
    <section className="section border-0 py-10 md:py-14 px-0">
      <SEO
        title="আমাদের কোর্সসমূহ — CreatorHaat"
        description="CreatorHaat-এর সব প্রিমিয়াম কোর্স দেখুন — USA YouTube Shorts Masterclass এবং YouTube Monetization & CPM Course। লাইভ ক্লাস ও লাইফটাইম সাপোর্ট সহ।"
        path="/courses"
      />
      <div className="container-x">
        <h1 className="section-title">আমাদের কোর্সসমূহ</h1>
        <p className="section-sub">প্রফেশনাল গাইডলাইনে শিখুন এবং নিজের ক্যারিয়ার গড়ুন</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {COURSES.map((c) => (
            <div key={c.slug} className="card overflow-hidden p-0">
              <Link to={c.path} className="block aspect-square overflow-hidden"><img src={c.image} alt={c.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" /></Link>
              <div className="p-5">
                <Link to={c.path}><h3 className="font-bold text-lg text-[var(--brand-navy)] mb-2 hover:text-[var(--brand-red)] transition">{c.title}</h3></Link>
                <p className="text-sm text-slate-600 line-clamp-3 mb-3">{c.description}</p>
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-slate-400 line-through">৳{c.regularPrice}</span>
                  <span className="text-2xl font-extrabold text-[var(--brand-red)]">৳{c.offerPrice}</span>
                </div>
                <Link to={c.path} className="btn-primary w-full justify-center">বিস্তারিত দেখুন</Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
