declare module "*.css";
declare module "*.webp.asset.json" {
  const value: { url: string; [key: string]: any };
  export default value;
}
