import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { LOGO_URL, COURSES } from "@/lib/data";
import EnrollModal from "./EnrollModal";

export default function Header() {
  const [open, setOpen] = useState(false);
  const [enrollOpen, setEnrollOpen] = useState(false);
  const navigate = useNavigate();

  const nav = [
    { to: "/", label: "হোম" },
    { to: "/courses", label: "কোর্স" },
    { to: "/about", label: "আমাদের সম্পর্কে" },
    { to: "/contact", label: "যোগাযোগ" },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-[var(--border)]">
      <div className="container-x flex items-center justify-between py-5 md:py-6">
        <Link to="/" className="flex items-center gap-2">
          <img src={LOGO_URL} alt="CreatorHaat" className="h-10 w-10 md:h-12 md:w-12 object-contain" />
          <span className="font-display text-xl md:text-2xl text-[var(--brand-navy)]">Creator<span className="text-[var(--brand-blue)]">Haat</span></span>
        </Link>

        <nav className="hidden md:flex items-center gap-7">
          {nav.map(n => (
            <Link key={n.to} to={n.to} className="text-sm font-semibold text-slate-700 hover:text-[var(--brand-red)] transition">{n.label}</Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button onClick={() => setEnrollOpen(true)} className="btn-primary !py-2 !px-4 text-sm md:!px-5">Enroll Now</button>
          <button className="md:hidden p-2 text-slate-700" onClick={() => setOpen(!open)} aria-label="Menu">
            {open ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-[var(--border)] bg-white">
          <div className="container-x py-3 flex flex-col gap-3">
            {nav.map(n => (
              <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="py-2 font-semibold text-slate-700">{n.label}</Link>
            ))}
          </div>
        </div>
      )}

      <EnrollModal
        open={enrollOpen}
        onClose={() => setEnrollOpen(false)}
        onSelect={(slug) => { setEnrollOpen(false); navigate(`/checkout/${slug}`); }}
        courses={COURSES}
      />
    </header>
  );
}
