import { Link } from "react-router-dom";
import { Mail, Phone, MapPin } from "lucide-react";
import { LOGO_URL, EMAIL, PHONE_DISPLAY, WHATSAPP_LINK } from "@/lib/data";

export default function Footer() {
  return (
    <footer className="bg-[var(--brand-navy)] text-slate-200 mt-16">
      <div className="container-x py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <img src={LOGO_URL} alt="CreatorHaat" className="h-10 w-10 bg-white rounded-lg p-1" />
            <span className="font-display text-xl">CreatorHaat</span>
          </div>
          <p className="text-sm text-slate-300">Learn Live • Build Skills • Grow Your Career — বাংলাদেশের আধুনিক স্কিল ডেভেলপমেন্ট প্ল্যাটফর্ম।</p>
          <div className="mt-3 text-sm">4.9/5 শিক্ষার্থীদের আস্থা ⭐</div>
        </div>
        <div>
          <h4 className="font-bold mb-3 text-white">Our Company</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/about" className="hover:text-white">About Us</Link></li>
            <li><Link to="/about" className="hover:text-white">Our Team</Link></li>
            <li><Link to="/courses" className="hover:text-white">Courses</Link></li>
            <li><Link to="/contact" className="hover:text-white">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-3 text-white">Get in Touch</h4>
          <ul className="space-y-2 text-sm">
            <li className="flex items-start gap-2"><Phone size={16} className="mt-0.5 shrink-0" /><a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="hover:text-white">{PHONE_DISPLAY}</a></li>
            <li className="flex items-start gap-2"><Mail size={16} className="mt-0.5 shrink-0" /><a href={`mailto:${EMAIL}`} className="hover:text-white">{EMAIL}</a></li>
            <li className="flex items-start gap-2"><MapPin size={16} className="mt-0.5 shrink-0" /><span>Naogaon Sadar, Rajshahi, Dhaka</span></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-3 text-white">আমাদের কোর্স</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/course/usa-shorts" className="hover:text-white">USA YouTube Shorts</Link></li>
            <li><Link to="/course/youtube-monetization" className="hover:text-white">YouTube Monetization & CPM</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-sm text-slate-400">
        Copyright © 2024. CreatorHaat. All Rights Reserved.
      </div>
    </footer>
  );
}
