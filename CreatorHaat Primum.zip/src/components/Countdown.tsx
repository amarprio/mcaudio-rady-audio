import { useEffect, useState } from "react";

export default function Countdown({ hours = 24 }: { hours?: number }) {
  const [target] = useState(() => Date.now() + hours * 3600 * 1000);
  const [t, setT] = useState(target - Date.now());
  useEffect(() => {
    const id = setInterval(() => setT(Math.max(0, target - Date.now())), 1000);
    return () => clearInterval(id);
  }, [target]);
  const d = Math.floor(t / 86400000);
  const h = Math.floor((t % 86400000) / 3600000);
  const m = Math.floor((t % 3600000) / 60000);
  const s = Math.floor((t % 60000) / 1000);
  const pad = (n: number) => n.toString().padStart(2, "0");
  return (
    <div className="flex items-center justify-center gap-2 md:gap-3 my-3">
      {[{v:d,l:"দিন"},{v:h,l:"ঘন্টা"},{v:m,l:"মিনিট"},{v:s,l:"সেকেন্ড"}].map((x,i)=>(
        <div key={i} className="flex flex-col items-center">
          <div className="countdown-box">{pad(x.v)}</div>
          <div className="countdown-label">{x.l}</div>
        </div>
      ))}
    </div>
  );
}
