import { Star } from "lucide-react";
import { REVIEWS } from "@/lib/data";

type Review = { name: string; role: string; text: string; rating: number };

export default function ReviewSection({ reviews }: { reviews?: Review[] } = {}) {
  const list = reviews ?? REVIEWS;
  return (
    <section className="section border-0 py-10 md:py-14 px-0 bg-[var(--bg-soft)]">
      <div className="container-x">
        <h2 className="section-title">শিক্ষার্থীদের অভিজ্ঞতা</h2>
        <p className="section-sub">হাজারো শিক্ষার্থীর শেখা ও সফলতার বিশ্বস্ত প্ল্যাটফর্ম — CreatorHaat। শুনে নিন তাদের গল্প।</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((r, i) => (
            <div key={i} className="card">
              <div className="flex gap-1 mb-3">
                {Array.from({length: r.rating}).map((_,j) => <Star key={j} size={18} fill="#fbbf24" stroke="#fbbf24" />)}
              </div>
              <p className="text-slate-700 text-[15px] leading-relaxed mb-4">"{r.text}"</p>
              <div className="flex items-center gap-3 pt-3 border-t border-slate-100">
                <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[var(--brand-red)] to-[var(--brand-orange)] text-white font-bold flex items-center justify-center">
                  {r.name.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-[var(--brand-navy)]">{r.name}</div>
                  <div className="text-xs text-slate-500">{r.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
