import { useEffect } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import type { Course } from "@/lib/data";

export default function EnrollModal({
  open, onClose, onSelect, courses,
}: { open: boolean; onClose: () => void; onSelect: (slug: string) => void; courses: Course[] }) {
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, [open]);
  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-[1000] bg-black/60 overflow-y-auto" onClick={onClose}>
      <div className="min-h-dvh flex items-center justify-center p-4 py-8">
        <div className="bg-white rounded-2xl max-w-lg w-full p-6 md:p-8 relative anim-up shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute right-3 top-3 p-2 text-slate-500 hover:text-slate-900" aria-label="Close"><X /></button>
        <h3 className="text-2xl font-bold text-[var(--brand-navy)] mb-2">কোর্স সিলেক্ট করুন</h3>
        <p className="text-sm text-slate-600 mb-5">যে কোর্সে এনরোল করতে চান সেটি বেছে নিন এবং চেকআউটে এগিয়ে যান।</p>
        <div className="flex flex-col gap-3">
          {courses.map(c => (
            <button key={c.slug} onClick={() => onSelect(c.slug)}
              className="text-left p-4 border-2 border-slate-200 rounded-xl hover:border-[var(--brand-red)] hover:bg-orange-50 transition group">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="font-bold text-[var(--brand-navy)] group-hover:text-[var(--brand-red)]">{c.title}</div>
                  <div className="text-sm text-slate-500 mt-1">
                    <span className="line-through">৳{c.regularPrice}</span> <span className="text-[var(--brand-red)] font-bold ml-2">৳{c.offerPrice}</span>
                  </div>
                </div>
                <div className="text-2xl">→</div>
              </div>
            </button>
          ))}
        </div>
        </div>
      </div>
    </div>,
    document.body
  );
}
