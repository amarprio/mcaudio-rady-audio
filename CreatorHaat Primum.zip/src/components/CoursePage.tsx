import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import type { Course } from "@/lib/data";
import { FAQS } from "@/lib/data";
import YouTubeEmbed from "@/components/YouTubeEmbed";
import Countdown from "@/components/Countdown";
import ReviewSection from "@/components/ReviewSection";
import ChannelScreenshots from "@/components/ChannelScreenshots";
import SEO from "@/components/SEO";
import { CheckCircle2, ChevronDown, Sparkles } from "lucide-react";

export default function CoursePage({ course }: { course: Course }) {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const navigate = useNavigate();

  const courseLd = {
    "@context": "https://schema.org",
    "@type": "Course",
    name: course.title,
    description: course.description,
    provider: { "@type": "Organization", name: "CreatorHaat", sameAs: "/" },
    offers: {
      "@type": "Offer",
      price: course.offerPrice,
      priceCurrency: "BDT",
      availability: "https://schema.org/InStock",
      url: course.path,
    },
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.9",
      reviewCount: course.reviews.length,
    },
  };

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: FAQS.map(f => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };

  return (
    <>
      <SEO
        title={`${course.title} — CreatorHaat`}
        description={course.description.slice(0, 158)}
        path={course.path}
        type="product"
        image={course.image}
        jsonLd={[courseLd, faqLd]}
      />
      {/* HERO */}
      <section className="hero-bg">
        <div className="container-x py-10 md:py-16 grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10 items-center">
          <div className="anim-up-2 order-1 lg:order-2">
            <img src={course.image} alt={course.title} className="rounded-2xl shadow-2xl w-full" />
          </div>

          <div className="order-2 lg:order-1 lg:hidden">
            <p className="text-sm font-semibold text-slate-700">অফারটি চলবে:</p>
            <Countdown hours={9} />
            <div className="mt-4 flex items-center gap-4 flex-wrap">
              <span className="text-slate-400 line-through text-lg">৳{course.regularPrice}</span>
              <span className="text-4xl font-extrabold text-[var(--brand-red)]">৳{course.offerPrice}</span>
              <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs font-bold">{course.discount}৳ ছাড়</span>
            </div>
            <button onClick={() => navigate(`/checkout/${course.slug}`)} className="btn-primary mt-4 w-full">এখনি এনরোল করুন</button>
          </div>

          <div className="anim-up order-3 lg:order-1">
            <div className="inline-flex items-center gap-2 bg-orange-100 text-[var(--brand-red)] px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
              <Sparkles size={16} /> অফার চলছে
            </div>
            <h1 className="font-display text-3xl md:text-5xl text-[var(--brand-navy)] leading-tight">{course.title}</h1>
            <p className="mt-4 text-slate-600 leading-relaxed">{course.description}</p>
            <div className="hidden lg:block">
              <div className="mt-6 flex items-center gap-4">
                <span className="text-slate-400 line-through text-lg">৳{course.regularPrice}</span>
                <span className="text-4xl font-extrabold text-[var(--brand-red)]">৳{course.offerPrice}</span>
                <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs font-bold">{course.discount}৳ ছাড়</span>
              </div>
              <p className="mt-3 text-sm font-semibold text-slate-700">অফারটি চলবে:</p>
              <Countdown hours={9} />
              <button onClick={() => navigate(`/checkout/${course.slug}`)} className="btn-primary mt-3">এখনি এনরোল করুন</button>
            </div>
          </div>
        </div>
      </section>

      {/* VIDEO */}
      <section className="section border-0 py-10 md:py-14 px-0">
        <div className="container-x max-w-3xl">
          <h2 className="section-title">কোর্স পরিচিতি ভিডিও</h2>
          <YouTubeEmbed id={course.youtubeId} title={course.title} />
        </div>
      </section>

      {/* WHY */}
      <section className="section border-0 py-10 md:py-14 px-0 bg-[var(--bg-soft)]">
        <div className="container-x max-w-5xl">
          <h2 className="section-title">কোর্সটা কেন করবেন?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            {course.whyTake.map((w, i) => (
              <div key={i} className="card flex gap-3 items-start">
                <CheckCircle2 className="text-[var(--brand-red)] shrink-0 mt-1" size={22} />
                <p className="text-slate-700">{w}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OUTLINE */}
      <section className="section border-0 py-10 md:py-14 px-0">
        <div className="container-x max-w-5xl">
          <h2 className="section-title">কোর্স আউটলাইন</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {course.outline.map((mod, i) => (
              <div key={i} className="card">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[var(--brand-red)] to-[var(--brand-orange)] text-white font-bold flex items-center justify-center text-sm">{i + 1}</div>
                  <h3 className="font-bold text-[var(--brand-navy)]">{mod.title}</h3>
                </div>
                <ul className="space-y-2">
                  {mod.items.map((it, j) => (
                    <li key={j} className="flex gap-2 text-sm text-slate-700"><CheckCircle2 size={16} className="text-green-600 shrink-0 mt-0.5" />{it}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="section border-0 py-10 md:py-14 px-0 bg-gradient-to-br from-[var(--brand-navy)] to-[#1e3a5f] text-white">
        <div className="container-x max-w-5xl">
          <h2 className="section-title text-white">Course Special Features</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6">
            {course.features.map((f, i) => (
              <div key={i} className="bg-white/10 backdrop-blur border border-white/10 rounded-xl p-4 flex items-center gap-2">
                <CheckCircle2 className="text-green-400 shrink-0" size={18} />
                <span className="text-sm font-medium">{f}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* STUDENT REVIEW VIDEOS */}
      <section className="section border-0 py-10 md:py-14 px-0">
        <div className="container-x max-w-5xl">
          <h2 className="section-title">স্টুডেন্ট রিভিউ</h2>
          <p className="section-sub">আমাদের স্টুডেন্টদের প্রকৃত অভিজ্ঞতা</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {course.reviewVideos.map((src, i) => (
              <video key={i} src={src} controls className="rounded-2xl w-full shadow-xl bg-black" />
            ))}
          </div>
        </div>
      </section>

      <ReviewSection reviews={course.reviews} />

      <ChannelScreenshots />

      {/* FAQ */}
      <section className="section border-0 py-10 md:py-14 px-0 bg-[var(--bg-soft)]">
        <div className="container-x max-w-3xl">
          <h2 className="section-title">আপনার প্রশ্নের উত্তর</h2>
          <div className="space-y-3 mt-6">
            {FAQS.map((f, i) => (
              <div key={i} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full p-4 flex items-center justify-between gap-3 text-left">
                  <span className="font-semibold text-[var(--brand-navy)]">{f.q}</span>
                  <ChevronDown className={`shrink-0 transition-transform ${openFaq === i ? "rotate-180" : ""}`} size={20} />
                </button>
                {openFaq === i && <div className="px-4 pb-4 text-slate-600 text-sm leading-relaxed">→ {f.a}</div>}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="section border-0 py-10 md:py-14 px-0 text-center bg-gradient-to-br from-[var(--brand-red)] to-[var(--brand-orange)] text-white">
        <div className="container-x max-w-2xl">
          <h2 className="text-2xl md:text-4xl font-extrabold mb-2">এখন কোর্সে জয়েন হলে পাবেন {course.discount}৳ ছাড়!</h2>
          <Countdown hours={9} />
          <Link to={`/checkout/${course.slug}`} className="btn-yellow mt-4">এনরোল করুন — ৳{course.offerPrice}</Link>
        </div>
      </section>
    </>
  );
}
