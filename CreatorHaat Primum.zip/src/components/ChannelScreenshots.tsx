import { CHANNEL_SCREENSHOTS } from "@/lib/data";

export default function ChannelScreenshots() {
  return (
    <section className="section border-0 py-10 md:py-14 px-0">
      <div className="container-x">
        <h2 className="section-title">Some Moments Of Our Achievements</h2>
        <p className="section-sub">আমাদের স্টুডেন্টদের সফল চ্যানেলগুলোর কিছু স্ক্রিনশট</p>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {CHANNEL_SCREENSHOTS.map((src, i) => (
            <div key={i} className="rounded-xl overflow-hidden border border-slate-200 bg-white group aspect-square">
              <img src={src} alt={`CreatorHaat student channel achievement ${i+1}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
